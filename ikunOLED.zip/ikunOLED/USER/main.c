//////////////////////////////////////////////////////////////////////////////////	 
//������ֻ��ѧϰʹ�ã�δ���������ɣ��������������κ���;
//�о�԰����
//���̵�ַ��http://shop73023976.taobao.com
//
//  �� �� ��   : main.c
//  �� �� ��   : v2.0
//  ��    ��   : HuangKai
//  ��������   : 2018-10-31
//  ����޸�   : 
//  ��������   : OLED I2C�ӿ���ʾ����(STM32F103ϵ��)
//              ˵��: 
//              ----------------------------------------------------------------
//              GND  ��Դ��
//              VCC  3.3v��Դ
//              D0   PA0��SCL��
//              D1   PA1��SDA��
//              RES  PA2
//              DC   PA3
//              CS   PA4 
//              ----------------------------------------------------------------
// �޸���ʷ   :
// ��    ��   : 
// ��    ��   : HuangKai
// �޸�����   : �����ļ�
//��Ȩ���У�����ؾ���
//Copyright(C) �о�԰����2018-10-31
//All rights reserved
//******************************************************************************/
#include "delay.h"
#include "sys.h"
#include "oled.h"
#include "bmp.h"
#include "stdio.h"
int main(void)
{
	//u8 t=' ';
	u8 i=0;
	delay_init();
	OLED_Init();
	OLED_ColorTurn(0);//0������ʾ��1 ��ɫ��ʾ
  OLED_DisplayTurn(0);//0������ʾ 1 ��Ļ��ת��ʾ
	while(1)
	{
//		int num = 42;
    char str[] = "BMP";
    u8 result[]= "hello,world"; 
		OLED_ShowPicture(30,0,64,58,BMP1,1);
		OLED_Refresh();
		delay_ms(400);
		OLED_ShowPicture(30,0,64,58,BMP2,1);
		OLED_Refresh();
		delay_ms(400);
		OLED_ShowPicture(30,0,64,58,BMP3,1);
		OLED_Refresh();
		delay_ms(400);
		OLED_ShowPicture(30,0,64,58,BMP4,1);
		OLED_Refresh();
		delay_ms(400);
		OLED_ShowPicture(30,0,64,58,BMP5,1);
		OLED_Refresh();
		delay_ms(400);
		OLED_ShowPicture(30,0,64,58,BMP6,1);
		OLED_Refresh();
		delay_ms(400);
		OLED_ShowPicture(30,0,64,58,BMP7,1);
		OLED_Refresh();
		delay_ms(400);
		OLED_ShowPicture(30,0,64,58,BMP6,1);
		OLED_Refresh();
		delay_ms(400);
		OLED_ShowPicture(30,0,64,58,BMP7,1);
		OLED_Refresh();
		delay_ms(400);
		OLED_ShowPicture(30,0,64,58,BMP8,1);
		OLED_Refresh();
		delay_ms(400);
		OLED_ShowPicture(30,0,64,58,BMP9,1);
		OLED_Refresh();
		delay_ms(400);
		OLED_ShowPicture(30,0,64,58,BMP10,1);
		OLED_Refresh();
		delay_ms(400);
		OLED_ShowPicture(30,0,64,58,BMP11,1);
		OLED_Refresh();
		delay_ms(400);
		OLED_ShowPicture(30,0,64,58,BMP12,1);
		OLED_Refresh();
		delay_ms(400);
		OLED_ShowPicture(30,0,64,58,BMP13,1);
		OLED_Refresh();
		delay_ms(400);
		OLED_ShowPicture(30,0,64,58,BMP14,1);
		OLED_Refresh();
		delay_ms(400);
		OLED_ShowPicture(30,0,64,58,BMP15,1);
		OLED_Refresh();
		delay_ms(400);
		OLED_ShowPicture(30,0,64,58,BMP16,1);
		OLED_Refresh();
		delay_ms(400);
		OLED_ShowPicture(30,0,64,58,BMP17,1);
		OLED_Refresh();
		delay_ms(400);
		OLED_ShowPicture(30,0,64,58,BMP18,1);
		OLED_Refresh();
		delay_ms(400);
		OLED_ShowPicture(30,0,64,58,BMP19,1);
		OLED_Refresh();
		delay_ms(400);
		OLED_ShowPicture(30,0,64,58,BMP20,1);
		OLED_Refresh();
		delay_ms(400);
		OLED_ShowPicture(30,0,64,58,BMP21,1);
		OLED_Refresh();
		delay_ms(400);
		OLED_ShowPicture(30,0,64,58,BMP22,1);
		OLED_Refresh();
		delay_ms(400);
		OLED_ShowPicture(30,0,64,58,BMP23,1);
		OLED_Refresh();
		delay_ms(400);
		OLED_ShowPicture(30,0,64,58,BMP24,1);
		OLED_Refresh();
		delay_ms(400);
		OLED_ShowPicture(30,0,64,58,BMP25,1);
		OLED_Refresh();
		delay_ms(400);
		OLED_ShowPicture(30,0,64,58,BMP26,1);
		OLED_Refresh();
		delay_ms(400);
		OLED_ShowPicture(30,0,64,58,BMP27,1);
		OLED_Refresh();
		delay_ms(400);
		
    //sprintf(result, "%s%d", str, num);
//		for(i=1;i<5;i++)
//		{
//		sprintf(result, "%s%d", str, i);
//		OLED_ShowPicture(30,0,64,58,result,1);
//		OLED_Refresh();
//		delay_ms(5000);
//		};
		//OLED_ShowPicture(0,1,128,64,BMP2,1);
		//OLED_DrawPoint(0,1,1);
//		int i;
//		for(i=0;i<127;i++)
//		{
//		OLED_DrawPoint(i,1,1);
//		}
		
		OLED_Refresh();
//		delay_ms(5000);
//		OLED_Clear();
//		OLED_ShowChinese(0,0,0,16,1);//��
//		OLED_ShowChinese(18,0,1,16,1);//��
//		OLED_ShowChinese(36,0,2,16,1);//԰
//		OLED_ShowChinese(54,0,3,16,1);//��
//		OLED_ShowChinese(72,0,4,16,1);//��
//		OLED_ShowChinese(90,0,5,16,1);//��
//		OLED_ShowChinese(108,0,6,16,1);//��
//		OLED_ShowString(8,16,"ZHONGJINGYUAN",16,1);
//		OLED_ShowString(20,32,"2014/05/01",16,1);
//		OLED_ShowString(0,48,"ASCII:",16,1);  
//		OLED_ShowString(63,48,"CODE:",16,1);
//		OLED_ShowChar(48,48,t,16,1);//��ʾASCII�ַ�	   
//		t++;
//		if(t>'~')t=' ';
//		OLED_ShowNum(103,48,t,3,16,1);
//		OLED_Refresh();
//		delay_ms(500);
//		OLED_Clear();
//		OLED_ShowChinese(0,0,0,16,1);  //16*16 ��
//	  OLED_ShowChinese(16,0,0,24,1); //24*24 ��
//		OLED_ShowChinese(24,20,0,32,1);//32*32 ��
//	  OLED_ShowChinese(64,0,0,64,1); //64*64 ��
//		OLED_Refresh();
//	  delay_ms(500);
//  	OLED_Clear();
//		OLED_ShowString(0,0,"ABC",8,1);//6*8 ��ABC��
//		OLED_ShowString(0,8,"ABC",12,1);//6*12 ��ABC��
//	  OLED_ShowString(0,20,"ABC",16,1);//8*16 ��ABC��
//		OLED_ShowString(0,36,"ABC",24,1);//12*24 ��ABC��
//	  OLED_Refresh();
//		delay_ms(500);
//		OLED_ScrollDisplay(11,4,1);
	}
}

